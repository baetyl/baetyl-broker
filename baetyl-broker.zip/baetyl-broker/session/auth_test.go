package session

import (
	"fmt"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestAuth(t *testing.T) {
	au := NewAuthenticator(nil)
	assert.Nil(t, au)

	p1 := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			{Action: "pub", Permits: []string{"+"}},
			{Action: "sub", Permits: []string{"+"}},
		}},
	}
	au = NewAuthenticator(p1)

	assert.Nil(t, au.AuthenticateAccount("", ""))
	assert.Nil(t, au.AuthenticateAccount("test", ""))
	assert.Nil(t, au.AuthenticateAccount("", "hahaha"))
	assert.Nil(t, au.AuthenticateAccount("test", "hahaha1"))
	assert.Nil(t, au.AuthenticateAccount("test1", "hahaha"))
	authorizer := au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)

	// "+" strategy validate
	assert.Equal(t, false, authorizer.Authorize(Publish, "/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "#"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/a"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "#"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/a"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+"))

	// "#" strategy validate
	p2 := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			{Action: "pub", Permits: []string{"#"}},
			{Action: "sub", Permits: []string{"#"}},
		}},
	}

	au = NewAuthenticator(p2)
	authorizer = au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)

	// assert.Equal(t, true, authorizer.Authorize(Publish, "+"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "#"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "/"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "//"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "/+"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "/#"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/+"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/#"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/#"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/b"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+/a"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+/#"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/a"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/a/+"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "+/a/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "#"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "/"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "//"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "/+"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/+"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/#"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/b"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+/a"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/a"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/a/+"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "+/a/#"))

	// "test/+" strategy validate
	p3 := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			{Action: "pub", Permits: []string{"test/+"}},
			{Action: "sub", Permits: []string{"test/+"}},
		}},
	}

	au = NewAuthenticator(p3)
	authorizer = au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)

	assert.Equal(t, false, authorizer.Authorize(Publish, "test"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "//"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "//a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "//+"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/test/a"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/test/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/test/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/test/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/test/a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/test/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+//"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+/a"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/+/+"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/c"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "test"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "//"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "//a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "//+"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/test/a"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/test/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/test/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/test/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/test/a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/test/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+//"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+/a"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/+/+"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/c"))

	// "a/+/b" strategy validate
	p4 := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			{Action: "pub", Permits: []string{"a/+/b"}},
			{Action: "sub", Permits: []string{"a/+/b"}},
		}},
	}

	au = NewAuthenticator(p4)
	authorizer = au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)

	// assert.Equal(t, true, authorizer.Authorize(Publish, "a/+/b"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "a/c/b"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "a//b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/#/b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+/b/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/c/d/b"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a///b"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "test/+/b"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "test/a/b"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "test//b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "test/#/b"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/c"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "a/+/b"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "a/c/b"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "a//b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/#/b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+/b/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/c/d/b"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a///b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "test/+/b"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "test/a/b"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "test//b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "test/#/b"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/c"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/#"))

	// "test/#" strategy validate
	p5 := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			{Action: "pub", Permits: []string{"test/#"}},
			{Action: "sub", Permits: []string{"test/#"}},
		}},
	}

	au = NewAuthenticator(p5)
	authorizer = au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)

	// assert.Equal(t, false, authorizer.Authorize(Publish, "+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "#"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "//"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "/#"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "+/#"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/#"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/+"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/b"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/+/b"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/+/"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/+/+"))
	// assert.Equal(t, true, authorizer.Authorize(Publish, "test/a/+/#"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/#"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+/b"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/+/#"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/+"))
	// assert.Equal(t, false, authorizer.Authorize(Publish, "a/b/#"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "#"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "//"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "/#"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "+/#"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/b"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/#"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/+"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/b"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/+/b"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/+/"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/+/+"))
	// assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/a/+/#"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/#"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+/b"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/+/#"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/+"))
	// assert.Equal(t, false, authorizer.Authorize(Subscribe, "a/b/#"))

	principals := []Principal{
		{
			Username: "test",
			Password: "hahaha",
			Permissions: []Permission{
				{Action: "pub", Permits: []string{"test", "benchmark", "test"}},
				{Action: "sub", Permits: []string{"test", "benchmark"}},
				{Action: "pub", Permits: []string{"test/中文"}},
				{Action: "sub", Permits: []string{"test/中文", "benchmark"}},
			},
		},
		{
			Username: "temp",
			Password: "lalala",
			Permissions: []Permission{
				{Action: "pub", Permits: []string{"test", "benchmark"}},
				{Action: "sub", Permits: []string{"test", "benchmark"}},
			},
		},
		{
			Username: "1",
			Permissions: []Permission{
				{Action: "pub", Permits: []string{"test", "benchmark"}},
				{Action: "sub", Permits: []string{"test", "benchmark"}},
			},
		},
	}

	// repeat authorizer process
	for _, principal := range principals {
		switch principal.Username {
		case "test":
			pubPermits, subPermits := getPubSubPermits(principal.Permissions)
			assert.Equal(t, 3, len(pubPermits))
			assert.Equal(t, 3, len(subPermits))
		case "temp":
			pubPermits, subPermits := getPubSubPermits(principal.Permissions)
			assert.Equal(t, 2, len(pubPermits))
			assert.Equal(t, 2, len(subPermits))
		case "":
			pubPermits, subPermits := getPubSubPermits(principal.Permissions)
			assert.Equal(t, 2, len(pubPermits))
			assert.Equal(t, 2, len(subPermits))
		}
	}

	au = NewAuthenticator(principals)
	// config username & password authenticate
	assert.NotNil(t, au.AuthenticateAccount("test", "hahaha"))
	assert.Nil(t, au.AuthenticateAccount("test", "lalala"))
	assert.NotNil(t, au.AuthenticateAccount("temp", "lalala"))
	assert.Nil(t, au.AuthenticateAccount("temp", "hahaha"))
	assert.NotNil(t, au.AuthenticateCertificate("1"))
	assert.Nil(t, au.AuthenticateCertificate("2"))

	authorizer = au.AuthenticateAccount("test", "hahaha")
	assert.NotNil(t, authorizer)
	// pub permission authorize
	assert.Equal(t, true, authorizer.Authorize(Publish, "test"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "benchmark"))
	assert.Equal(t, true, authorizer.Authorize(Publish, "test/中文"))
	assert.Equal(t, false, authorizer.Authorize(Publish, "temp"))

	// sub permission authorize
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "benchmark"))
	assert.Equal(t, true, authorizer.Authorize(Subscribe, "test/中文"))
	assert.Equal(t, false, authorizer.Authorize(Subscribe, "temp"))
}

func getPubSubPermits(permissions []Permission) ([]string, []string) {
	permissions = duplicatePubSubPermitRemove(permissions)
	pubPermits := make([]string, 0)
	subPermits := make([]string, 0)
	for _, permission := range permissions {
		switch permission.Action {
		case Publish:
			pubPermits = permission.Permits
		case Subscribe:
			subPermits = permission.Permits
		}
	}
	return pubPermits, subPermits
}

func TestPrincipalsValidate(t *testing.T) {
	c := new(Config)
	c.SysTopics = []string{"$baidu", "$link"}

	// round 0-1: no principals
	err := principalsValidate(nil, "")
	assert.NoError(t, err)

	// round 0-2: empty principals
	err = principalsValidate([]Principal{}, "")
	assert.NoError(t, err)

	// round 1: regular principals config validate
	principals := []Principal{{
		Username: "test",
		Password: "hahaha",
		Permissions: []Permission{
			Permission{Action: "pub", Permits: []string{"test", "benchmark", "#", "+", "test/+", "test/#"}},
			Permission{Action: "sub", Permits: []string{"test", "benchmark", "#", "+", "test/+", "test/#"}},
		}}, {
		Username: "temp",
		Password: "3f29e1b2b05f8371595dc761fed8e8b37544b38d56dfce81a551b46c82f2f56b",
		Permissions: []Permission{
			Permission{Action: "pub", Permits: []string{"test", "benchmark", "a/+/b", "+/a/+", "+/a/#"}},
			Permission{Action: "sub", Permits: []string{"test", "benchmark", "a/+/b", "+/a/+", "+/a/#"}},
		}}}
	err = principalsValidate(principals, "")
	assert.NoError(t, err)

	// round 2: duplicate username validate
	principals = principals[:len(principals)-1]
	principals = append(principals, Principal{
		Username: "test",
		Password: "3f29e1b2b05f8371595dc761fed8e8b37544b38d56dfce81a551b46c82f2f56b",
		Permissions: []Permission{
			Permission{Action: "pub", Permits: []string{"test", "benchmark"}},
		}})
	err = principalsValidate(principals, "")
	assert.NotNil(t, err)
	assert.Equal(t, fmt.Sprintf("username (test) duplicate"), err.Error())

	// round 3: invalid publish topic validate
	principals = principals[:len(principals)-1]
	principals = append(principals, Principal{
		Username: "hello",
		Password: "3f29e1b2b05f8371595dc761fed8e8b37544b38d56dfce81a551b46c82f2f56b",
		Permissions: []Permission{
			Permission{Action: "pub", Permits: []string{"test/a+/b", "benchmark"}},
		}})
	err = principalsValidate(principals, "")
	assert.NotNil(t, err)
	assert.Equal(t, fmt.Sprintf("pub topic(test/a+/b) invalid"), err.Error())

	// round 4: invalid subscribe topic validate
	principals = principals[:len(principals)-1]
	principals = append(principals, Principal{
		Username: "hello",
		Password: "3f29e1b2b05f8371595dc761fed8e8b37544b38d56dfce81a551b46c82f2f56b",
		Permissions: []Permission{
			Permission{Action: "pub", Permits: []string{"test", "benchmark"}},
			Permission{Action: "sub", Permits: []string{"test", "test/#/temp"}},
		}})
	err = principalsValidate(principals, "")
	assert.NotNil(t, err)
	assert.Equal(t, fmt.Sprintf("sub topic(test/#/temp) invalid"), err.Error())
}
