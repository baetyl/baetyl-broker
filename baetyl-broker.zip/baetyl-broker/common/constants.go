package common

// DefaultMqttAddress the default mqtt address
const DefaultMqttAddress = "tcp://0.0.0.0:1883"
